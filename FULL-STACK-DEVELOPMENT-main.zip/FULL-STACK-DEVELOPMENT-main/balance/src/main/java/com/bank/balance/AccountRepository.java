package com.bank.balance;

public interface AccountRepository {
    String getBalance();
}
