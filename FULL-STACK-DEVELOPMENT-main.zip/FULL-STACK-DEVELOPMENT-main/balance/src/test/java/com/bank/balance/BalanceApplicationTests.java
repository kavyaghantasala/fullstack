package com.bank.balance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BalanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
